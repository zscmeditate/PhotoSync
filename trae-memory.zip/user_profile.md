## Identity & Form of Address
- Primary communication language: Chinese

## Communication & Collaboration Preferences
- UI design: prefers more prominent visual elements (e.g., larger buttons, eye-catching gradients for key items)
- When adjusting Android UI, prioritize alignment with provided design specifications for colors, dimensions, corner radii, and element positions unless logical consistency cannot be maintained

## Tech Stack & Methods
- Android development, Java (proficient)
- XML layout files, viewBinding (proficient)

## Interests & Lifestyle
- Audio waveform aesthetics: prefers 2/3 height utilization with 1/6 top/bottom margins, and 3-point smoothing window for balance between detail and continuity