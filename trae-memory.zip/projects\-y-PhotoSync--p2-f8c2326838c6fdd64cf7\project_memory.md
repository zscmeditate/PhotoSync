## Hard Constraints
- All file path prefixes must be normalized (backslash to forward slash, collapsed slashes, no '..' segments) to prevent path traversal and overlap conflicts
- Upload/download operations must only commit changes to local index after full integrity verification (size and SHA-256 match) to avoid false sync state
- Sync event ACKs must only be sent after local file operations complete successfully to prevent lost or duplicated sync actions
- Bulk deletion operations require explicit confirmation when exceeding 50 items within a 10-minute window to prevent accidental mass data loss

## Engineering Conventions
- Server-side endpoints follow strict permission checks: non-members receive 403 SPACE_FORBIDDEN, non-owner resources return 404 to avoid exposure
- Room database uses formal migrations (no destructive fallback) for production releases
- Sync manifest calculations filter by directory mapping prefix to avoid cross-mapping file mismatches
- Conflict resolution supports three modes: server (keep server version), client (submit version), both (retain both versions as conflict copy)
- Trash items are retained for 30 days before automatic permanent purge
- Android UI adjustments must follow provided design specifications for colors, dimensions, corner radii, and element positions unless logical consistency cannot be maintained

## Lessons Learned
- Scanning failures or incomplete directory traversal must not be treated as bulk file deletion; retain old index data and mark scan status as incomplete
- Split upload requests must use numeric size/partSize fields in JSON to match server API contract
- Remote paths exactly matching a directory prefix must be explicitly excluded from file mapping to prevent incorrect sync planning
- Fake file creation path conflict checks must exclude soft-deleted files to avoid incorrect conflict detection